//Clase enumerada
namespace Gym.App.Dominio
{
    public enum TypeOfEat{
        //Definimos los valores que va a tener este objeto
        Breakfast,
        MidMorning,
        Food,
        MidAfternoon,
        Dinner
    }
}