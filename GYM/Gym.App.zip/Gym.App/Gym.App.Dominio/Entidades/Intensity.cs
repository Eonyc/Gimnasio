//Clase enumerada
namespace Gym.App.Dominio
{
    public enum Intensity{
        //Definimos los valores que va a tener este objeto
        Beginner,
        Intermediate,
        Advanced
    }
}