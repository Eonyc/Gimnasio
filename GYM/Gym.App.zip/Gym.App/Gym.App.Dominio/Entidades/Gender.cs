//Clase enumerada
namespace Gym.App.Dominio
{
    public enum Gender{
        //Definimos los valores que va a tener este objeto
        Male,
        Female,
        Bisexual,
        Intersexual,
        Pansexual,
        Transexual
    }
}