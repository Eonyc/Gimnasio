//Clase enumerada
namespace Gym.App.Dominio
{
    public enum BodyPart{
        //Definimos los valores que va a tener este objeto
        UpperBody,
        LowerBody,
        AbdominalCore
    }
}