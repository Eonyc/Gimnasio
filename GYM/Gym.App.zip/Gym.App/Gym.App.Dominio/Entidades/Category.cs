//Clase enumerada
namespace Gym.App.Dominio
{
    public enum Category{
        //Definimos los valores que va a tener este objeto
        Hit,
        Power,
        Pilates,
        Kickboxing,
        Cardio,
        Yoga
    }
}